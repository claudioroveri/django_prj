"""project URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from app.views import home, form, create, carro, view, delete, delete2, update, edit
from django.contrib import admin

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home, name='home'),
    path('carro/', carro, name='carro'),
    path('form/', form, name='form'),
    path('create/', create, name='create'),
    path('delete/<int:pk>/', delete, name='delete'),
    path('delete2/<int:pk>/', delete2, name='delete2'),
    path('edit/<int:pk>/', edit, name='edit'),
    path('update/<int:pk>/', update, name='update'),
    path('view//', view, name="view"),
    path('api/v1/', include('app.api.urls', namespace='api')),
    path('api-auth', include('rest_framework.urls', namespace='rest_framework')),
]
