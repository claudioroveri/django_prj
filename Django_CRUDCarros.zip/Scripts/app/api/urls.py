from rest_framework.routers import DefaultRouter
from app.views import CarrosViewSet, MarcaViewSet

app_name = 'api'

# Esse 3 comandos fazem o conjunto de URL
# com padrão REST, utilizando a raiz carros
router = DefaultRouter(trailing_slash=False)
router.register(r'carros', CarrosViewSet)
router.register(r'marca', MarcaViewSet)

urlpatterns = router.urls