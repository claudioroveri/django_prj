from django.forms import ModelForm
from app.models import Carros, Marca

# Aqui são criados os Beans para os formularios
class CarrosForm(ModelForm):
    class Meta:
        model = Carros
        fields = ['id','modelo', 'marca', 'ano', 'automatico']

class MarcaForm(ModelForm):
    class Meta:
        model = Marca
        fields = ['descricao', 'origem', 'luxo']




